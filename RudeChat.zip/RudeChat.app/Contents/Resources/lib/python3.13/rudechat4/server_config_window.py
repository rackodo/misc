from rudechat4.shared_imports import *
from rudechat4.global_variables import *
from rudechat4.channel_expand import ChannelExp
from rudechat4.rude_logger import configure_logging

class ServerConfigWindow(QScrollArea):
    def __init__(self, parent, config_file, close_callback):
        super().__init__()
        self.parent = parent
        self.config_file = config_file
        self.close_callback = close_callback
        self.setViewportMargins(-10, -10, -10, -10)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.widget = QWidget()
        self.widget.layout = QVBoxLayout(self.widget)
        self.setWidget(self.widget)

        self.config = configparser.ConfigParser()
        self.config.read(config_file)

        self.channels = self.config.get('IRC', 'auto_join_channels')
        
        self.label_map = {
            'server_name': ['Server Name', 'string'],
            'nickname': ['Nickname', 'string'],
            'server': ['Server Address', 'string'],
            'auto_join_channels': ['Auto-Join Channels', 'ChannelSelect'],
            'use_nickserv_auth': ['Use NickServ Authentication', 'bool'],
            'nickserv_password': ['NickServ Password', 'string'],
            'port': ['Port', 'string'],
            'ssl_enabled': ['SSL Enabled', 'bool'],
            'sasl_enabled': ['SASL Enabled', 'bool'],
            'sasl_username': ['SASL Username', 'string'],
            'sasl_password': ['SASL Password', 'string'],
            'use_time_stamp': ['Use Time Stamps?', 'bool'],
            'show_hostmask': ['Show Hostmasks?', 'bool'],
            'show_join_part_quit_nick': ['Show Join/Part/Quit Messages?', 'bool'],
            'use_beep_noise': ['Use Beep Noises?', 'bool'],
            'auto_whois': ['Auto WHOIS Users?', 'bool'],
            'custom_sounds': ['Custom Sounds', 'bool'],
            'mention_note_color': ['Mention Channel Highlight', 'string'],
            'activity_note_color': ['Activity Channel Highlight', 'string'],
            'use_logging': ['Turn Logging On/Off', 'bool'],
            'znc_connection': ['Use ZNC Connection', 'bool'],
            'znc_password': ['ZNC Password', 'string'],
            'ignore_cert': ['Ignore SSL Certs?', 'bool'],
            'znc_user': ['ZNC Username', 'string'],
            'replace_pronouns': ['Replace Pronouns?', 'bool'],
            'display_user_modes': ['Display User Modes?', 'bool'],
            'use_auto_join': ['Use Auto Join?', 'bool'],
            'auto_rejoin': ['Auto Rejoin on Kick?', 'bool'],
            'use_irc_colors': ['Enable/Disable IRC Colors', 'bool'],
            'send_ctcp_response': ['Respond to CTCP Requests?', 'bool'],
            'green_text': ['Green Text Styling', 'bool'],
            'auto_away_minutes': ['Time Until Auto Away', 'string'],
            'use_auto_away': ['Use Auto Away?', 'bool'],
            'auto_join_invite': ['Auto Join On Invite?', 'bool'],
            'log_on': ['Turn Client Debug Logging On', 'bool'],
            'use_emojis': ['Turn Emoji filters on/off', 'bool'],
        }
        configure_logging()
        self.entries = {}
        self.create_widgets()

    def create_widgets(self):
        self.entries = {}
        self.create_config_widgets()

    def create_config_widgets(self):
        row_count = 0  # Track row number for grid positioning

        for section in self.config.sections():
            section_frame = QGroupBox()
            
            section_frame.layout = QGridLayout(section_frame)
            section_frame.layout.setColumnStretch(0, 1)
            section_frame.layout.setColumnStretch(1, 1)

            for option in self.config.options(section):
                label = QLabel(section_frame, text=self.label_map.get(option, option)[0])
                label.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred))
                
                label.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

                section_frame.layout.addWidget(label, row_count, 0, 1, 1)

                match self.label_map.get(option, option)[1]:
                    case 'bool':
                        entry = QCheckBox(section_frame)
                        entry.setChecked(self.config.getboolean(section, option))
                        
                    case 'string':
                        entry = QLineEdit(section_frame)
                        entry.setText(self.config.get(section, option))
                        
                    case 'ChannelSelect':
                        button = QPushButton(section_frame, text="Edit Channels")
                        button.clicked.connect(self.expand_channels_list)
                        entry = button
                    
                section_frame.layout.addWidget(entry, row_count, 1, 1, 1)

                self.entries[(section, option)] = entry
                row_count += 1
            try:
                self.widget.layout.itemAt(0).widget().setParent(None)
            except:
                print("No widget to remove")

            self.widget.layout.addWidget(section_frame)

    def expand_channels_list(self):
        channels = self.channels
        if channels:
            self.expander = ChannelExp(channels, self.set_channels )

            self.expander.show()

    def set_channels(self, new_channels):
        self.channels = new_channels

    def save_config(self):
        try:
            # Create a new configuration object
            new_config = configparser.ConfigParser()

            for (section, option), entry in self.entries.items():
                match self.label_map.get(option, option)[1]:
                    case 'bool':
                        value = str(entry.isChecked())
                    case 'string':
                        value = entry.text()
                    case 'ChannelSelect':
                        value = self.channels
                # Add the entry to the new configuration
                if not new_config.has_section(section):
                    new_config.add_section(section)
                new_config.set(section, option, value)

            # Extract server name from the entries
            server_name = new_config.get('IRC', 'server_name')

            # Generate new configuration file path in the script directory using server_name
            new_config_file = os.path.join(G_CONFIG_DIR, f"{server_name.lower()}.rudeserver")

            with open(new_config_file, 'w') as configfile:
                new_config.write(configfile)

            self.close_callback()
        except configparser.NoOptionError as e:
            logging.error(f"Error saving configuration: Option '{e.option}' not found in section '{e.section}'.")
        except Exception as e:
            logging.error(f"Error saving configuration: {e}")